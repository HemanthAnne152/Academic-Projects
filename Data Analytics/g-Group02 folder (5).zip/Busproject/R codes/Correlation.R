# prepare data (for a specific group)
S = readRDS('routes_aggr.rds')
T = S %>% filter(peak == "Peak", weekday == "Weekday")
U = T %>% dplyr::select(-c(bus_operator, route, peak, weekday))

# explore data

####correlation matrix
u.cor=cor(U)
view(cor(U))
write.csv(u.cor,'C:\\Users\\vt00196\\OneDrive - University of Surrey\\Desktop\\bus service\\outputs\\cor.csv')
install.packages("corrplot")
library(corrplot)
corrplot(u.cor)
pairs(u.cor)


####correlation plot 1
library(corrplot)
corrplot(cor(U),        # Correlation matrix
         method = "shade", # Correlation plot method
         type = "full",    # Correlation plot style (also "upper" and "lower")
         diag = TRUE,      # If TRUE (default), adds the diagonal
         tl.col = "black", # Labels color
         bg = "white",     # Background color
         title = "",       # Main title
         col = NULL)   

####correlation plot 2
p_load(GGally)
ggpairs(U) 

####correlation plot 3
library("GGally")

my_fn <- function(data, mapping, pts=list(), smt=list(), ...){
  ggplot(data = data, mapping = mapping, ...) + 
    do.call(geom_point, pts) +
    do.call(geom_smooth, smt) 
}
ggpairs(U[, 1:10], 
        lower = list(continuous = 
                       wrap(my_fn,
                            pts=list(size=1, colour="blue"), 
                            smt=list(method="lm", se=F, size=1, colour="black"))),
)



