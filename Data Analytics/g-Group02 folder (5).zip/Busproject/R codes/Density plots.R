S=read.csv("C:\\Users\\ps01114\\OneDrive - University of Surrey\\Desktop\\BA 1st sem\\DA\\Bus Assessment\\Outputs\\op.csv")
#Best subsets regression
S$lghd<-log(S$headway_avg)
S$lgdv<-log(S$deviation_avg)

#Density plot for deviation
hist(S$deviation_avg, 
     col = c("#009999"),
     border = "black", 
     prob = TRUE, 
     main = "Deviation Distribution Plot", 
     xlab="Deviation",
     ylim=c(0, 0.007)) 
lines(density(S$deviation_avg),lwd = 2, col = "red")

#Density plot for headway
hist(S$headway_avg, 
     col = c("#009999"),
     border = "black", 
     prob = TRUE, 
     main = "Headway Distribution Plot", 
     xlab="Headway",)
lines(density(S$headway_avg),lwd = 2, col = "red")

#Density plot for passenger
hist(S$passengers_avg, 
     col = c("#009999"),
     border = "black", 
     prob = TRUE, 
     main = "Passenger Distribution Plot",
     xlab="Passenger")
lines(density(S$passengers_avg),lwd = 2, col = "red")

#Density plot for log_headway_avg
hist(S$lghd, 
     col = c("#CCFF00"),
     border = "black", 
     prob = TRUE, 
     main = "Ln(headway_avg) Distribution Plot",
     xlab="Ln(headway_avg)")
lines(density(S$lghd),lwd = 2, col = "red")

#Density plot for log_deviation_avg
hist(S$lgdv, 
     col = c("#CCFF00"),
     border = "black", 
     prob = TRUE, 
     main = "Ln(deviation_avg) Distribution Plot",
     ylim = c(0,1.2),
     xlab="Ln(deviation_avg)")
lines(density(S$lgdv),lwd = 2, col = "red")

#Density plot for Train stations
hist(S$train_stations, 
     col = c("#009999"),
     border = "black", 
     prob = TRUE, 
     main = "Train station Distribution Plot", 
     xlab="Train station")
lines(density(S$train_stations),lwd = 2, col = "red")
