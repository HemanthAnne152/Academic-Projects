library (readxl)
library (readr)
library(dplyr)
library(ggplot2)
df<- read.csv("C:\\Users\\ps01114\\OneDrive - University of Surrey\\Desktop\\BA 1st sem\\DA\\Bus Assessment\\routes_daily_distinct.csv")
dx<-select(df, passengers,route,day,weekday,peak )

##summary of passengers
summary(df$passengers)
dx2<- group_by(dx, route,day,weekday,peak)
summary(dx2$passengers)

#histogram of passengers grouped by route,day,peak, weekday
hist(dx2$passengers, col= "yellow", main="Histogram for Passengers", xlab="Passengers by grouping by route, peak, day and weeekday")                                   # Draw histogram
abline(v = mean(dx2$passengers),                       # Add line for mean
       col = "red",
       lwd = 3)
text(x =mean(dx2$passengers) * 2.6,                 # Add text for mean
     y = mean(dx2$passengers) * 30,
     paste("Mean =", mean(dx2$passengers)),
     col = "red", 
     cex = 1)
abline(v = median(dx2$passengers),                       # Add line for median
       col = "red",
       lwd = 3)
text(x =median(dx2$passengers) * 3.8,                 # Add text for median
     y = median(dx2$passengers) * 50,
     paste("Median =", median(dx2$passengers)),
     col = "red",
     cex = 1)

##headways in seconds
summary(df$headway)
hist(df$headway, col= "light blue", main="Histogram for Headway", xlab="Headway")                                   # Draw histogram
abline(v = mean(df$headway, na.rm= TRUE),                       # Add line for mean
       col = "red",
       lwd = 3)

text(x =mean(df$headway, na.rm= TRUE) *2.4,                 # Add text for mean
     y = mean(df$headway, na.rm= TRUE) *8,
     paste("Mean =", mean(df$headway, na.rm= TRUE)),
     col = "red",
     cex =1)
abline(v = median(df$headway, na.rm= TRUE),                       # Add line for median
       col = "red",
       lwd = 3)
text(x =median(df$headway, na.rm= TRUE) *2.6,                 # Add text for median
     y = median(df$headway, na.rm= TRUE) *16,
     paste("Median =", median(df$headway, na.rm= TRUE)),
     col = "red",
     cex = 1)

##deviation in seconds
summary(df$deviation)
hist(df$deviation, col= "light blue", main="Histogram for Deviation", xlab="Deviation")                                   # Draw histogram
abline(v = mean(dx2$passengers),                       # Add line for mean
       col = "red",
       lwd = 3)
text(x =mean(dx2$passengers) * 2.6,                 # Add text for mean
     y = mean(dx2$passengers) * 30,
     paste("Mean =", mean(dx2$passengers)),
     col = "red", 
     cex = 1)
abline(v = median(dx2$passengers),                       # Add line for median
       col = "red",
       lwd = 3)
text(x =median(dx2$passengers) * 3.8,                 # Add text for median
     y = median(dx2$passengers) * 50,
     paste("Median =", median(dx2$passengers)),
     col = "red",
     cex = 1)

summary(df$train_stations)
summary(df$hospitals)
