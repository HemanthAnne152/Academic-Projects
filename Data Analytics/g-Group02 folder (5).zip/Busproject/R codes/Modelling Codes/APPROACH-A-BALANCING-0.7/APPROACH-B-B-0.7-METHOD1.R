
list.files()
# Initialise
cat('\14'); rm(list=ls());graphics.off(); 
# source('easyDBaccess.R'); saveRDS(df, "routes_aggr.rds")
library(pacman); p_load(tidyverse)
getwd()
setwd("C://Users//vr00214//OneDrive - University of Surrey//Desktop//Sem 1")
#setwd(dirname(getwd()))
source("HumanNumbers.R")
rmse  <- function(y,yh) {sqrt(mean((y-yh)^2))}
mape  <- function(y,yh) {mean(abs((y-yh)/y))} # y=actual value, yh=modelled value (note issue when y is zero!)
frmse <- function(y,yh) {fmt(rmse(y,yh))}
fmape <- function(y,yh) {fmt(mape(y,yh)*100,'%')}
derr  <- function(y,yh,model="") {disp(model,'rmse=',frmse(y,yh),', mape=',fmape(y,yh))}
aplot <- function(y,yh, main="") {
  plot(y, yh, pch='.', cex=8, col = 'black', 
       ylab = "modelled", xlab = "observed",main=main); 
  abline(0,1, lwd=3, col='red');
}
# prepare data (for a specific group)
#S = readRDS('routes_aggr.rds')
S=read.csv("C://Users//vr00214//OneDrive - University of Surrey//Desktop//Sem 1//DA2//routes_aggr_distinct1.csv")
T = S %>% filter(peak == "Peak", weekday == "Weekday")
U = T %>% dplyr::select(-c(X,bus_operator, route, peak, weekday))

# define train (and test) rows
nr = length(unique(T$route)); nt=floor(.7*nr);
set.seed(1); train = sample(1:nr, nt);
## A few default models: LM, LR, DT and RF
# linear model
m1 <- lm ( passengers_avg~., data = U[train,])
yh  = predict(m1, newdata=U[-train,])
y   = U$passengers_avg[-train]
summary(m1)
derr(y,yh,"LM: "); aplot(y,yh,"LM")

# linear regression (normal equation)
p_load(MASS)
ya = U$passengers_avg[train]
pX = U %>% dplyr::select(-c(passengers_avg))
X = as.matrix( pX[train,]) 
b = ginv(t(X) %*% X) %*% t(X) %*% ya

y = U$passengers_avg[-train]
Xt = as.matrix( pX[-train,]) 
yh = Xt %*% b
derr(y,yh,"LR: "); aplot(y,yh,"LR")
summary(b)
# in theory this should be the same as LM, 
# but the underlying calculations differ

# decision tree
p_load(tree)
dt = tree(passengers_avg~., data = U, subset=train)
yh  = predict(dt, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"DT: "); aplot(y,yh,"DT")

# random forest
p_load(randomForest)
set.seed(1); # fix random number
rf = randomForest(formula = passengers_avg~., data = U, subset=train, importance = TRUE)
yh  = predict(rf, newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"RF: "); aplot(y,yh,"RF")
I = importance(rf);I = I[order(-I[,1]),]
varImpPlot(rf)

###svm
#install.packages("kernlab")
#install.packages("caret")
library(kernlab)
library(caret)

model_rfdot_svm<-ksvm(passengers_avg~.,data = U,kernel = "rbfdot")
yh<-predict(model_rfdot_svm,newdata=U[-train,])
y   = U$passengers_avg[-train]
derr(y,yh,"SVM: "); aplot(y,yh,"SVM")



