S=read.csv("C://Users//vr00214//OneDrive - University of Surrey//Desktop//Sem 1//DA2//routes_aggr_distinct1.csv")
#Best subsets regression
S$lghd<-log(S$headway_avg)
S$lgdv<-log(S$deviation_avg)
T = S %>% filter(peak == "Peak", weekday == "Weekday")
U = T %>% dplyr::select(-c(X,bus_operator, route, peak, weekday,headway_avg,deviation_avg))
source("HumanNumbers.R")
rmse  <- function(y,yh) {sqrt(mean((y-yh)^2))}
mape  <- function(y,yh) {mean(abs((y-yh)/y))} # y=actual value, yh=modelled value (note issue when y is zero!)
frmse <- function(y,yh) {fmt(rmse(y,yh))}
fmape <- function(y,yh) {fmt(mape(y,yh)*100,'%')}
derr  <- function(y,yh,model="") {disp(model,'rmse=',frmse(y,yh),', mape=',fmape(y,yh))}
aplot <- function(y,yh, main="") {
  plot(y, yh, pch='.', cex=8, col = 'black', 
       ylab = "modelled", xlab = "observed",main=main); 
  abline(0,1, lwd=3, col='red');
}
normalize<-function(x){
  return ( (x-min(x))/(max(x)-min(x)))
}
concrete_norm<-as.data.frame(lapply(U,FUN=normalize))
summary(concrete_norm$passengers_avg)
concrete_train<-concrete_norm[1:68,]
concrete_test<-concrete_norm[69:87,]
# Using multilayered feed forward nueral network
# package nueralnet
#install.packages("neuralnet")
#install.packages("nnet")
library(neuralnet)
library(nnet)
# Building model
concrete_model <- neuralnet(passengers_avg~.,data = concrete_train)
str(concrete_model)
plot(concrete_model)
# SSE sum of squared errors . least SSE best model
# Evaluating model performance
# compute function to generate ouput for the model prepared
model_results <- compute(concrete_model,concrete_test[2:10])
predicted_strength <- model_results$net.result
predicted_strength
plot(concrete_test$passengers_avg, predicted_strength, col='blue', pch=16, ylab = "predicted passenger NN", xlab = "real passenger")
abline(0,1)
RMSE.NN = (sum((concrete_test$passengers_avg - predicted_strength)^2) / nrow(concrete_test)) ^ 0.5
cor(predicted_strength,concrete_test$passengers_avg)
# New model
model_5<-neuralnet(passengers_avg~.,data= concrete_norm,hidden = c(5,3))
plot(model_5)
model_5_res<-compute(model_5,concrete_test[2:10])
pred_strn_5<-model_5_res$net.result
plot(concrete_test$passengers_avg, pred_strn_5, col='blue', pch=16, ylab = "predicted passengers NN", xlab = "real passengers")
abline(0,1)
RMSE.NN = (sum((concrete_test$passengers_avg - pred_strn_5)^2) / nrow(concrete_test)) ^ 0.5
cor(pred_strn_5,concrete_test$passengers_avg)
