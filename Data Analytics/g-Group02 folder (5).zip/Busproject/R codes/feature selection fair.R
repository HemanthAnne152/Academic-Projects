set.seed(7)
#library(olsrr)
library(pacman); p_load(tidyverse)
# load the library
#install.packages("mlbench")
library(mlbench)
library(caret)

# prepare training scheme
control <- trainControl(method="repeatedcv", number=10, repeats=3)
# train the model
S=read.csv("C:\\Users\\ps01114\\OneDrive - University of Surrey\\Desktop\\BA 1st sem\\DA\\Bus Assessment\\Outputs\\op.csv")
T = S %>% filter(peak == "Peak", weekday == "Weekday")
UU = T %>% dplyr::select(-c(X,bus_operator, route, peak, weekday))
aa<- data.frame(UU)
model <- train(passengers_avg~., data=aa, method="lm", preProcess="scale", trControl=control)
# estimate variable importance
importance <- varImp(model, scale=FALSE)
# summarize importance
print(importance)
# plot importance
plot(importance)

